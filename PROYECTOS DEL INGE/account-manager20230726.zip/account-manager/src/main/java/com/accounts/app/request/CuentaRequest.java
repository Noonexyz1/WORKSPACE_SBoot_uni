package com.accounts.app.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public record CuentaRequest(
        @NotBlank(message = "Moneda inválida")
        @Pattern(regexp = "^(USD|BOB|UFV)$", message = "Moneda inválida")
        String moneda,
        @Min(value = 1, message = "Cliente inválido")
        Long clienteId
) {}
