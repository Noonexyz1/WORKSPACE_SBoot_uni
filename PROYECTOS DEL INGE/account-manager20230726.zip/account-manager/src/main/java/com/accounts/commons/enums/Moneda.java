package com.accounts.commons.enums;

public enum Moneda {
    BOB, USD, UFV
}
