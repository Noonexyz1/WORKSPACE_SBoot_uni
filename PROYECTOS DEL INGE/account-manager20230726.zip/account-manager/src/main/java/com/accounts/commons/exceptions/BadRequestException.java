package com.accounts.commons.exceptions;

import lombok.Getter;

@Getter
public class BadRequestException extends RuntimeException {
    private String code;

    public BadRequestException() {
        super();
    }

    public BadRequestException(String message) {
        super(message);
    }

    public BadRequestException(String code, String message) {
        super(message);
        this.code = code;
    }
}
