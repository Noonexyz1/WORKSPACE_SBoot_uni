package com.accounts.app.config;

import com.accounts.commons.api.ApiError;
import com.accounts.commons.enums.ErrMsg;
import com.accounts.commons.exceptions.BadRequestException;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.List;
import java.util.stream.Collectors;

@ControllerAdvice
public class RestExceptionHandler {
    @ExceptionHandler(HttpMessageNotReadableException.class)
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex) {
        return buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, ErrMsg.JSON_PROCESSING.getCod(), ErrMsg.JSON_PROCESSING.getMsg()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
        List<String> list = ex.getBindingResult().getAllErrors().stream()
                .map(ObjectError::getDefaultMessage)
                .collect(Collectors.toList());
        return buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, ErrMsg.ARG_NOT_VALID.getCod(), String.join(", ", list)));
    }
    @ExceptionHandler(BadRequestException.class)
    protected ResponseEntity<Object> handleMethodBadException(BadRequestException ex) {
        return buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, ex.getCode(), ex.getMessage()));
    }

    @ExceptionHandler(FeignException.class)
    protected ResponseEntity<Object> handleMethodFeignException(FeignException ex) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            ApiError apiError = mapper.readValue(ex.contentUTF8(), ApiError.class);
            return buildResponseEntity(new ApiError(HttpStatus.valueOf(ex.status()), apiError.getCode(), apiError.getMessage()));
        } catch (Exception e) {
            return buildResponseEntity(new ApiError(HttpStatus.NOT_ACCEPTABLE, ErrMsg.CNN_REFUSED.getCod(),ErrMsg.CNN_REFUSED.getMsg()));
        }
    }

    @ExceptionHandler(Exception.class)
    protected ResponseEntity<Object> handleGenericException(Exception ex) {
        return buildResponseEntity(new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, ErrMsg.GENERIC_ERROR.getCod(), ErrMsg.GENERIC_ERROR.getMsg()));
    }

    private ResponseEntity<Object> buildResponseEntity(ApiError apiError) {
        return new ResponseEntity<>(apiError, apiError.getStatus());
    }
}
