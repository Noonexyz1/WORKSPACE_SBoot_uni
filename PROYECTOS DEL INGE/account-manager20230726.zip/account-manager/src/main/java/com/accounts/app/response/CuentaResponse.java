package com.accounts.app.response;

import com.accounts.commons.enums.Moneda;
import lombok.Builder;

import java.math.BigDecimal;

@Builder
public record CuentaResponse(
        String numeroCuenta,
        Moneda moneda,
        BigDecimal saldoDisponible,
        String habilitado
) {}
