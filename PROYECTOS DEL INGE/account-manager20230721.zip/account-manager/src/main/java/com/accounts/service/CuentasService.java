package com.accounts.service;

import com.accounts.app.request.CuentaRequest;
import com.accounts.app.response.CuentaResponse;
import com.accounts.commons.enums.Moneda;
import com.accounts.model.Cuenta;
import com.accounts.provider.ClientesProvider;
import com.accounts.provider.record.Cliente;
import com.accounts.repository.CuentaRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.UUID;

@Service
public class CuentasService {
    @Autowired
    CuentaRepository repository;
    @Autowired
    ClientesProvider provider;

    public CuentaResponse crear(CuentaRequest request){
        Cliente cliente= provider.detalle(request.clienteId());
        Cuenta cuenta =repository.save(Cuenta.builder()
                .moneda(Moneda.valueOf(request.moneda()))
                .numero(UUID.randomUUID().toString())
                .saldo(BigDecimal.ZERO)
                .saldoDisponible(BigDecimal.ZERO)
                .habilitado(true)
                .clienteId(cliente.id())
                .build());
        return CuentaResponse.builder()
                .numeroCuenta(cuenta.getNumero())
                .moneda(cuenta.getMoneda())
                .saldoDisponible(cuenta.getSaldoDisponible())
                .habilitado(cuenta.isHabilitado()?"SI":"NO")
                .build();
    }
}
