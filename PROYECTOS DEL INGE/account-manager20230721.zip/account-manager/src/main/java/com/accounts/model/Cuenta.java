package com.accounts.model;

import com.accounts.commons.enums.Moneda;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@Entity
@Table(name="cuenta")
@NoArgsConstructor
@AllArgsConstructor
public class Cuenta {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;

    @Column(name="fecha_creacion")
    @CreationTimestamp
    private LocalDateTime creacion;

    @Column(name="fecha_actualizacion")
    @UpdateTimestamp
    private LocalDateTime actualizacion;

    private String numero;

    @Enumerated(EnumType.STRING)
    private Moneda moneda;

    private BigDecimal saldo = BigDecimal.ZERO;

    @Column(name = "saldo_disponible")
    private BigDecimal saldoDisponible = BigDecimal.ZERO;

    private boolean habilitado;

    @Column(name = "cliente_id")
    private Long clienteId;

}
