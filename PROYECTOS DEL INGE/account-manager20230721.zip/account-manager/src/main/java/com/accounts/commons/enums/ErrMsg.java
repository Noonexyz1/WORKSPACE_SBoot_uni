package com.accounts.commons.enums;

public enum ErrMsg {
    JSON_PROCESSING("001", "Malformed JSON request"),
    ARG_NOT_VALID("002", "ARGUMENTO NO VALIDO"),
    NAME_IS_NOT_VALID("003", "El nombre ya se encuentra registrado"),
    BAD_REQUEST_CLIENT("004", "No hemos podido encontrar al cliente"),
    CNN_REFUSED("998", "Error de comunicacion"),
    GENERIC_ERROR("999", "Comuniquese con sistemas");
    private final String code;
    private final String message;
    private ErrMsg(String code, String message){
        this.code = code;
        this.message = message;
    }
    public String getCod(){
        return code;
    }
    public String getMsg(){
        return message;
    }
}
