package com.client.service;

import com.client.commons.constatns.ErrMsg;
import com.client.commons.exceptions.BadRequestException;
import com.client.model.Cliente;
import com.client.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClienteService {
    @Autowired
    private ClienteRepository repository;

    public Cliente crear(Cliente cliente){
        if(repository.existsByNombres(cliente.getNombres())){
            throw new BadRequestException(ErrMsg.NAME_IS_NOT_VALID.getCod(),ErrMsg.NAME_IS_NOT_VALID.getMsg());
        }
        return repository.save(cliente);
    }

    public List<Cliente> recuperaTodo(){
        return repository.findAll();
    }
    public Cliente detalle(Long id){
        return repository.findById(id)
                .orElseThrow(()-> new BadRequestException(ErrMsg.BAD_REQUEST_CLIENT.getCod(),ErrMsg.BAD_REQUEST_CLIENT.getMsg()));
    }

}
